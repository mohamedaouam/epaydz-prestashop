<?php

namespace Chargily\ePay\Exceptions;

use Exception;

class InvalidConfigurationsException extends Exception
{
}
