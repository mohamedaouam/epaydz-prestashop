<?php

namespace Chargily\ePay\Exceptions;

use Exception;

class InvalidResponseException extends Exception
{
}
